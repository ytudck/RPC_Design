package com.dcqq.rpc.protocol.ZookeeperConfs;

import com.dcqq.rpc.protocol.log.ProLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;

/**
 * @author duchengkun
 * 服务发现
 * @description todo
 * @date 2019-04-08 16:54
 */
public class ServiceDiscover extends ProLog implements Serializable {
    public ServiceDiscover(Logger logger) {
        super(LoggerFactory.getLogger(ServiceDiscover.class));
    }

    @Override
    public void beginsign(Logger logger, String msg) {

    }
}
