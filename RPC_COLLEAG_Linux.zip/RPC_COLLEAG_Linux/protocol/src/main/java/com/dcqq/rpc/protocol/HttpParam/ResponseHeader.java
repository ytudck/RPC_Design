package com.dcqq.rpc.protocol.HttpParam;

import java.io.Serializable;

/**
 * @author duchengkun
 * 数据返回_头部实体
 * @description todo
 * @date 2019-04-08 17:24
 */
public class ResponseHeader extends CommonHeader implements Serializable {
    private boolean isSuccessFlag;
    public ResponseHeader(Long requestid, byte seritype, byte compresstype, byte condition, Integer bodysize) {
        super(requestid, seritype, compresstype, condition, bodysize);
    }

    public boolean isSuccessFlag() {
        return isSuccessFlag;
    }

    public void setSuccessFlag(boolean successFlag) {
        isSuccessFlag = successFlag;
    }
}
