package com.dcqq.rpc.protocol.ZookeeperConfs;

import com.dcqq.rpc.protocol.log.ProLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;

/**
 * @author duchengkun
 * 服务注册
 * @description todo
 * @date 2019-04-08 16:53
 */
public class ServiceRegister extends ProLog implements Serializable {
    public ServiceRegister(Logger logger) {
        super(LoggerFactory.getLogger(ServiceRegister.class));
    }

    @Override
    public void beginsign(Logger logger, String msg) {

    }
}
