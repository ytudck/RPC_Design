package com.dcqq.rpc.protocol.HttpParam;

import java.io.Serializable;

/**
 * @author duchengkun
 * 请求
 * @description todo
 * @date 2019-04-03 18:57
 */
public class RpcResquest<T> implements Serializable {
    private RequestHeader header;
    private T content;//RequestBody

    public RpcResquest(){}

    public RpcResquest(RequestHeader header, T content) {
        this.header = header;
        this.content = content;
    }

    public RequestHeader getHeader() {
        return header;
    }

    public void setHeader(RequestHeader header) {
        this.header = header;
    }

    public T getContent() {
        return content;
    }

    public void setContent(T content) {
        this.content = content;
    }
}
