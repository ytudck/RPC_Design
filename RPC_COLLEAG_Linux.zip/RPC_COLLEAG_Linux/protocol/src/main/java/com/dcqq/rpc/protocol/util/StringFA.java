package com.dcqq.rpc.protocol.util;

/**
 * @author duchengkun
 * 首字母大小写转换工具
 * @description todo
 * @date 2019-04-16 18:23
 */
public class StringFA {
    public static String lowerFirstCase(String name){
        char[] chars = name.toCharArray();
        chars[0]+=32;
        return String.valueOf(chars);
    }
}
