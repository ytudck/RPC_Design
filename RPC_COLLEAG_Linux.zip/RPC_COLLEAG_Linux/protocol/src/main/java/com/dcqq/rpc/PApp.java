package com.dcqq.rpc;

/**
 * @author duchengkun
 * @description todo
 * @date 2019-04-03 18:51
 */
public class PApp {
    public static void main(String args[]){
        //hello world
    }
}
