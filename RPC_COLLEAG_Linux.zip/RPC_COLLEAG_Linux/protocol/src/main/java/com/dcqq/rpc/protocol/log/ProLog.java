package com.dcqq.rpc.protocol.log;

import org.slf4j.Logger;

import java.io.Serializable;

/**
 * @author duchengkun
 * @description todo
 * 统一日志收集  Info
 * @date 2019-04-08 11:27
 */
public abstract class ProLog implements Serializable {
    private Logger logger;

    public ProLog(Logger logger) {
        this.logger = logger;
    }

    public Logger getLogger() {
        return logger;
    }

    public void setLogger(Logger logger) {
        this.logger = logger;
    }

    //Info
    public void design(String msg){
        beginsign(logger,msg);
    }

    //开始记录
    public abstract  void beginsign(Logger logger,String msg);
}
