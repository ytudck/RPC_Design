package com.dcqq.rpc.protocol.ZookeeperConfs;


import java.io.Serializable;

/**
 * @author Zookeeper的配置类
 * @description todo
 * @date 2019-04-03 18:57
 */
public class CliZKCnf implements Serializable{
    private String ip;
    private String port;
    private String datalocs;

    public CliZKCnf(String ip, String port,String datalocs) {
        this.ip = ip;
        this.port = port;
        this.datalocs = datalocs;
    }

    public CliZKCnf() {
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public String getDatalocs() {
        return datalocs;
    }

    public void setDatalocs(String datalocs) {
        this.datalocs = datalocs;
    }
}
