package com.dcqq.rpc.protocol.callback;

//请求成功的回调函数
public interface RpcResultCallBack<T> {
    Object getMess(T future);
}
