package com.dcqq.rpc.protocol.HttpParam;

import java.io.Serializable;

/**
 * @author duchengkun
 * 请求头
 * @description todo
 * @date 2019-04-08 17:23
 */
public class RequestHeader extends CommonHeader implements Serializable {
    public RequestHeader(Long requestid, byte seritype, byte compresstype, byte condition, Integer bodysize) {
        super(requestid, seritype, compresstype, condition, bodysize);
    }
}
