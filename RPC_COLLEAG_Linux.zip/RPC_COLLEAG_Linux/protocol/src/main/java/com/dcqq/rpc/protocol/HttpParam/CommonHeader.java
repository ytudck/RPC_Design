package com.dcqq.rpc.protocol.HttpParam;

/**
 * @author duchengkun
 * @description todo
 * @date 2019-04-03 19:00
 */
public class CommonHeader {
    //请求id（8个字节）
    private Long requestid;
    //序列化版本
    private byte seritype;
    //压缩版本
    private byte compresstype;
    //心跳检测，正常请求
    private byte condition;
    //消息体长度(RequestBody)  4个byte
    private Integer bodysize;

    public CommonHeader(Long requestid, byte seritype, byte compresstype, byte condition, Integer bodysize) {
        this.requestid = requestid;
        this.seritype = seritype;
        this.compresstype = compresstype;
        this.condition = condition;
        this.bodysize = bodysize;
    }

    public Long getRequestid() {
        return requestid;
    }

    public void setRequestid(Long requestid) {
        this.requestid = requestid;
    }

    public byte getSeritype() {
        return seritype;
    }

    public void setSeritype(byte seritype) {
        this.seritype = seritype;
    }

    public byte getCompresstype() {
        return compresstype;
    }

    public void setCompresstype(byte compresstype) {
        this.compresstype = compresstype;
    }

    public byte getCondition() {
        return condition;
    }

    public void setCondition(byte condition) {
        this.condition = condition;
    }

    public Integer getBodysize() {
        return bodysize;
    }

    public void setBodysize(Integer bodysize) {
        this.bodysize = bodysize;
    }
}
