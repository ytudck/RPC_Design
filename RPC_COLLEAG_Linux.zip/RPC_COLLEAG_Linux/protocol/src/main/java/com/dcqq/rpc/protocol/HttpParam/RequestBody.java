package com.dcqq.rpc.protocol.HttpParam;

import java.io.Serializable;

/**
 * @author edianzu
 * 请求体(封装了请求相关的信息)
 * @description todo
 * @date 2019-04-03 19:00
 */
public class RequestBody implements Serializable {
    //服务名称
    private String servicename;
    //方法名称
    private String methodname;
    //请求参数
    private Object[] params;

    //请求参数的类型
    private Class<?> paramsType[];

    //constructor
    public RequestBody(String servicename, String methodname, Object[] params,Class<?> paramTypes[]) {
        this.servicename = servicename;
        this.methodname = methodname;
        this.params = params;
        this.paramsType = paramTypes;
    }

    public String getServicename() {
        return servicename;
    }

    public void setServicename(String servicename) {
        this.servicename = servicename;
    }

    public String getMethodname() {
        return methodname;
    }

    public void setMethodname(String methodname) {
        this.methodname = methodname;
    }

    public Object[] getParams() {
        return params;
    }

    public void setParams(Object[] params) {
        this.params = params;
    }

    public Class<?>[] getParamsType() {
        return paramsType;
    }

    public void setParamsType(Class<?>[] paramsType) {
        this.paramsType = paramsType;
    }
}
