package com.dcqq.rpc.protocol;

/**
 * @author duchengkun
 * @description todo
 * @date 2019-04-03 18:51
 */
public class App {
    /**
     * 位置项目目录完整性
     */
}
