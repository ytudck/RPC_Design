package com.dcqq.rpc.protocol.HttpParam;

import java.io.Serializable;

/**
 * @author duchengkun
 * @description todo
 * @date 2019-04-03 18:57
 */
public class RpcReponse<T> implements Serializable {
    //响应头
    private ResponseHeader header;
    //相应体
    private T content;

    public RpcReponse() {
    }

    public RpcReponse(ResponseHeader header, T content) {
        this.header = header;
        this.content = content;
    }

    public ResponseHeader getHeader() {
        return header;
    }

    public void setHeader(ResponseHeader header) {
        this.header = header;
    }

    public T getContent() {
        return content;
    }

    public void setContent(T content) {
        this.content = content;
    }
}
