package com.dcqq.rpc.protocol.util;

/**
 * @author duchengkun
 * 封装请求的一些常用的参数
 * @description todo
 * @date 2019-04-20 18:17
 */
public class CommonContants {
    public static final int COMMON_BODY_SIZE = 16;
}
