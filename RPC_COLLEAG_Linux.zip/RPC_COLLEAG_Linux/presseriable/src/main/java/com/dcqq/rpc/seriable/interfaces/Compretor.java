package com.dcqq.rpc.seriable.interfaces;

//将数据压缩
public interface Compretor {
    //压缩
    byte[] compress(byte[] target);
    //解压缩
    byte[] decompress(byte[] target);
}
