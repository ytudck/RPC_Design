package com.dcqq.rpc.seriable;

/**
 * @author duchengkun
 * @description todo
 * @date 2019-04-03 19:49
 * test类
 */
public class App {
    //main  method
}
