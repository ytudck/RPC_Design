package com.dcqq.rpc.seriable.compress;

import com.dcqq.rpc.seriable.interfaces.Compretor;
import com.dcqq.rpc.seriable.log.SerLogger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xerial.snappy.Snappy;

import java.io.IOException;

/**
 * @author edianzu
 * @description todo
 * @date 2019-04-08 11:13
 */
public class SnappyCompress extends SerLogger implements Compretor {
    public SnappyCompress(Logger logger) {
        super(LoggerFactory.getLogger(SnappyCompress.class));
    }

    //压缩
    @Override
    public byte[] compress(byte[] target) {
        if(target != null){
            try{
                return Snappy.compress(target);
            }catch (IOException e){
                e.printStackTrace();
            }
        }
        return null;
    }

    //解压缩
    @Override
    public byte[] decompress(byte[] target) {
        if(target != null){
            try{
                return Snappy.uncompress(target);
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        return null;
    }

    @Override
    public void gisnLog(Logger logger, String msg) {
        logger.info(msg);
    }
}
