package com.dcqq.rpc.seriable.compress;

import com.dcqq.rpc.seriable.interfaces.Compretor;
import com.dcqq.rpc.seriable.log.SerLogger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author duchengkun
 * @description todo
 * @date 2019-04-08 11:05
 * 默认不对数据进行压缩
 */
public class DoNotCompress extends SerLogger implements Compretor {
    public DoNotCompress(Logger logger) {
        super(LoggerFactory.getLogger(DoNotCompress.class));
    }

    @Override
    public byte[] compress(byte[] target) {
        return target;
    }

    @Override
    public byte[] decompress(byte[] target) {
        return target;
    }

    @Override
    public void gisnLog(Logger logger, String msg) {
        logger.info(msg);
    }
}
