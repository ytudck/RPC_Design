package com.dcqq.rpc.seriable.enums;

import com.dcqq.rpc.seriable.compress.DoNotCompress;
import com.dcqq.rpc.seriable.compress.GzipCompress;
import com.dcqq.rpc.seriable.compress.SnappyCompress;
import com.dcqq.rpc.seriable.interfaces.Compretor;
import org.slf4j.Logger;

/**
 * 我们采用的压缩方式的枚举类
 */
public enum CompressUtity {

    DONOT(3),//no
    GZIP(4),//gzip
    SNAPPY(5);//snappy

    private int value;


    private CompressUtity(int value) {
        this.value = value;
    }

    public static Compretor getCompress(int value){
        Logger logger = null;
        switch (value){
            case 4:{
                return new GzipCompress(logger);
            }
            case 5:{
                return new SnappyCompress(logger);
            }
            default:
                return new DoNotCompress(logger);
        }
    }
    //DEFAULT VALUE
    public static final CompressUtity DEFAULT = CompressUtity.DONOT;
}
