package com.dcqq.rpc.seriable.objtobytes;

import com.caucho.hessian.io.Hessian2Input;
import com.caucho.hessian.io.Hessian2Output;
import com.dcqq.rpc.seriable.interfaces.Serialization;
import com.dcqq.rpc.seriable.log.SerLogger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

/**
 * @author duchengkun
 * @description todo
 * @date 2019-04-08 10:56
 * Hession2方式的数据序列化
 */
public class Hession2OtoB extends SerLogger implements Serialization {

    public Hession2OtoB(Logger logger) {
        super(LoggerFactory.getLogger(Hession2OtoB.class));
    }

    @Override
    public byte[] serilize(Object obj) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        Hessian2Output output = new Hessian2Output(baos);
        try{
            output.writeObject(obj);
            output.flush();
        }catch (Exception e){
            e.printStackTrace();
        }
        return baos.toByteArray();
    }

    @Override
    public <T> T descerilize(byte[] bytes, Class<T> clazz) throws IOException {
        ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
        Hessian2Input input = new Hessian2Input(bais);
        return (T)input.readObject(clazz);
    }

    @Override
    public void gisnLog(Logger logger, String msg) {
        logger.info(msg);
    }
}
