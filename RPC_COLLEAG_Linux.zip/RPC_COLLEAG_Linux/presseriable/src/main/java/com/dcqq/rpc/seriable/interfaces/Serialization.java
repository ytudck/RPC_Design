package com.dcqq.rpc.seriable.interfaces;

import java.io.IOException;

public interface Serialization {
    //序列化
    byte[] serilize(Object obj);
    //反序列化
    <T> T descerilize(byte[] bytes,Class<T> clazz) throws IOException;
}
