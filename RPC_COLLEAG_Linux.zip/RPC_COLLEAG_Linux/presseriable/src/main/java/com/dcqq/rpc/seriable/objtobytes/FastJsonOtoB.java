package com.dcqq.rpc.seriable.objtobytes;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.JSONSerializer;
import com.alibaba.fastjson.serializer.SerializeWriter;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.dcqq.rpc.seriable.interfaces.Serialization;
import com.dcqq.rpc.seriable.log.SerLogger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author duchengkun
 * @description todo
 * @date 2019-04-08 10:46
 * fastjson的形式进行序列化
 */
public class FastJsonOtoB extends SerLogger implements Serialization {

    public FastJsonOtoB(Logger logger) {
        super(LoggerFactory.getLogger(FastJsonOtoB.class));
    }

    /**
     * 序列化数据
     * @param obj
     * @return
     */
    @Override
    public byte[] serilize(Object obj) {
        SerializeWriter writer = new SerializeWriter();
        JSONSerializer jsonSerializer = new JSONSerializer(writer);
        jsonSerializer.config(SerializerFeature.WriteEnumUsingToString,true);
        jsonSerializer.config(SerializerFeature.WriteClassName,true);

        jsonSerializer.write(obj);
        return writer.toBytes(null);
    }

    /**
     * 反序列化
     * @param bytes
     * @param clazz
     * @param <T>
     * @return
     */
    @Override
    public <T> T descerilize(byte[] bytes, Class<T> clazz) {
        return JSON.parseObject(new String(bytes),clazz);
    }

    @Override
    public void gisnLog(Logger logger,String msg) {
        logger.info(msg);
    }
}
