package com.dcqq.rpc.seriable.compress;

import com.dcqq.rpc.seriable.interfaces.Compretor;
import com.dcqq.rpc.seriable.log.SerLogger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * @author duchengkun
 * @description todo
 * @date 2019-04-08 11:06
 * gzip压缩的方式对数据进行压缩
 */
public class GzipCompress extends SerLogger implements Compretor {

    public GzipCompress(Logger logger) {
        super(LoggerFactory.getLogger(GzipCompress.class));
    }

    /**
     * 压缩
     * @param target
     * @return
     */
    @Override
    public byte[] compress(byte[] target) {
        if(target == null) return null;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        GZIPOutputStream gos = null;
        try{
            gos = new GZIPOutputStream(baos);
            gos.write(target);
            gos.close();
        }catch (Exception e){
            e.printStackTrace();
        }
        return baos.toByteArray();
    }

    /**
     * 解压缩
     * @param target
     * @return
     */
    @Override
    public byte[] decompress(byte[] target) {
        if(target == null) return null;
        ByteArrayInputStream bis = new ByteArrayInputStream(target);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        GZIPInputStream gin = null;
        try{
            gin = new GZIPInputStream(bis);
            byte[] buffer = new byte[256];
            int n;
            while((n = gin.read(buffer)) >= 0){
                baos.write(buffer,0,n);
            }
        }catch (Exception e){
            e.printStackTrace();
        }

        return baos.toByteArray();
    }

    @Override
    public void gisnLog(Logger logger, String msg) {
        logger.info(msg);
    }
}
