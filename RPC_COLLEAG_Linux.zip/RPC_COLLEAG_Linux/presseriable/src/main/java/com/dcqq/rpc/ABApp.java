package com.dcqq.rpc;

/**
 * @author duchengkun
 * @description todo
 * @date 2019-04-03 19:48
 */
public class ABApp {
    /**
     * keep the struct of project is prefect
     * so
     * this class do not delete anyway
     */
}
