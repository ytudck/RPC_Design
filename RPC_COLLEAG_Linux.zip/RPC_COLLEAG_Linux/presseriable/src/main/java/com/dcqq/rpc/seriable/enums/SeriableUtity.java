package com.dcqq.rpc.seriable.enums;

import com.dcqq.rpc.seriable.interfaces.Serialization;
import com.dcqq.rpc.seriable.objtobytes.FastJsonOtoB;
import com.dcqq.rpc.seriable.objtobytes.Hession2OtoB;
import org.slf4j.Logger;

/**
 * 序列化方式的枚举
 */
public enum SeriableUtity {

    //默认采取不序列化的方式  Seriables
    Fastjson(1),//json
    Hession2(2);//object序列化

    private int value;
    private SeriableUtity(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public void setValue(byte value) {
        this.value = value;
    }

    /**
     * 获取数据序列化的方式
     * @param value
     * @return
     */
    public static Serialization getSerialization(int value){
        Logger logger = null;
        switch (value){
            case 1:
                return new FastJsonOtoB(logger);
            case 2:
                return new Hession2OtoB(logger);
            default:
                return null;
        }
    }

    public final static SeriableUtity DEFAULT_SERIABLES = SeriableUtity.Hession2;
}
