package com.dcqq.rpc.seriable.log;

import org.slf4j.Logger;

import java.io.Serializable;

/**
 * @author duchengkun
 * @description todo
 * 统一日志搜集
 * @date 2019-04-08 11:24
 */
public abstract class SerLogger implements Serializable {
    private Logger logger ;

    public SerLogger(Logger logger) {
        this.logger = logger;
    }

    public Logger getLogger() {
        return logger;
    }

    public void setLogger(Logger logger) {
        this.logger = logger;
    }

    public void doLog(Logger logger,String msg){
        gisnLog(logger,msg);
    }

    //开始记录日志
    public abstract void gisnLog(Logger logger,String msg);
}
