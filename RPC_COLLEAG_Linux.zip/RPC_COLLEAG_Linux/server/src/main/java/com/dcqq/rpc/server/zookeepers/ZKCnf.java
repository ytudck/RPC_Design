package com.dcqq.rpc.server.zookeepers;

/**
 * @author duchengkun
 * @description todo
 * zookeeper配置
 * @date 2019-05-05 14:40
 */
public class ZKCnf {
    private String ip;
    private int port;
    private String dataloc;
    private String servername;

    public ZKCnf(String ip, int port,String dataloc,String servername) {
        this.ip = ip;
        this.port = port;
        this.dataloc = dataloc;
        this.servername = servername;
    }

    public ZKCnf() {
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public String getDataloc() {
        return dataloc;
    }

    public void setDataloc(String dataloc) {
        this.dataloc = dataloc;
    }

    public String getServername() {
        return servername;
    }

    public void setServername(String servername) {
        this.servername = servername;
    }
}
