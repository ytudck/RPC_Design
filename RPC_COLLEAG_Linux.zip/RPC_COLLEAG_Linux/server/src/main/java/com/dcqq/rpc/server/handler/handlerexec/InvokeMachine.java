package com.dcqq.rpc.server.handler.handlerexec;

import com.dcqq.rpc.server.logs.SerLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Method;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.locks.ReentrantLock;

/**
 * @author duchengkun
 * 具体的反射的类
 * @description todo
 * @date 2019-04-10 15:51
 */
public class InvokeMachine extends SerLog {

    //存放service ----->  class
    private volatile static ConcurrentHashMap<String,Class<?>> result_map = new ConcurrentHashMap<String,Class<?>>();
    //保证了线程之间的数据可见性(但是并不可以保证操作的原子性)
    private volatile static InvokeMachine invokeMachine = null;
    //确保操作,进程之间的一致性(线程同步)
    private static CountDownLatch latch = new CountDownLatch(1);

    //开启公平锁(根据排队的序列进行操作)  true--->公平锁,false---->非公平锁
    private ReentrantLock lock = new ReentrantLock(true);//公平锁比较耗费系统性能

    public InvokeMachine() {
        super(LoggerFactory.getLogger(InvokeMachine.class));
    }

    public static InvokeMachine getinstance() throws InterruptedException {
        synchronized (InvokeMachine.class){
            if(invokeMachine == null){
                try{
                    invokeMachine = new InvokeMachine();
                    latch.countDown();
                }finally {
                    latch.await();
                }
            }
        }
        // backtrack
        return invokeMachine;
    }

    public static InvokeMachine getInvokeMachine() {
        return invokeMachine;
    }

    public static void setInvokeMachine(InvokeMachine invokeMachine) {
        InvokeMachine.invokeMachine = invokeMachine;
    }

    public ConcurrentHashMap<String, Class<?>> getResult_map() {
        return result_map;
    }

    public void setResult_map(ConcurrentHashMap<String, Class<?>> result_map) {
        this.result_map = result_map;
        signlog("set InvokeMachine result map is successfully,the data is ->{}"+result_map);
    }

    /**
     * 用来执行回调函数
     * @param methodname
     * @param servicename
     * @param params
     * @param latch
     * @return
     */
    public Object exec(String methodname, String servicename, Object[] params,
                       Class<?>[] paramTypes, CountDownLatch latch) {
        signlog("true brgin invoke method,using reflect");
        Object result = null;
        lock.lock();
        try{
            //日志操作
            Class<?> clazz = result_map.get(servicename);
            signlog(clazz.getTypeName());
            getLogger().debug("get invoke class ->{}",clazz);
            //JDK
            Method method = clazz.getMethod(methodname,paramTypes);
            method.setAccessible(true);
            result = method.invoke(clazz.newInstance(), params);
            latch.countDown();
            getLogger().info("invoke result ->{}",result);
            //日志操作
            //CGLIB

        }catch (Exception e){
            //日志
            getLogger().error("error invoke in sync->{}",e);
        }finally {
            lock.unlock();
        }
        return result;
    }


    @Override
    public void beginsign(Logger logger, String message) {
        logger.info(message);
    }
}
