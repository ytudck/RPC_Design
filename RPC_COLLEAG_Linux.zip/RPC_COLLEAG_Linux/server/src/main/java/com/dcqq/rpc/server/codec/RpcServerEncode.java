package com.dcqq.rpc.server.codec;

import com.dcqq.rpc.protocol.HttpParam.ResponseHeader;
import com.dcqq.rpc.protocol.HttpParam.RpcReponse;
import com.dcqq.rpc.seriable.enums.CompressUtity;
import com.dcqq.rpc.seriable.enums.SeriableUtity;
import com.dcqq.rpc.seriable.interfaces.Compretor;
import com.dcqq.rpc.seriable.interfaces.Serialization;
import com.dcqq.rpc.server.constant.EventType;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author duchengkun
 * 对RpcReponse进行编码
 * @description 消息编码器
 * @date 2019-04-09 11:20
 */
public class RpcServerEncode extends MessageToByteEncoder<RpcReponse> {

    private Logger logger = LoggerFactory.getLogger(RpcServerEncode.class);
    /**
     * 消息编码
     * @param channelHandlerContext
     * @param rpcReponse
     * @param byteBuf
     * @throws Exception
     */
    @Override
    protected void encode(ChannelHandlerContext channelHandlerContext,
                          RpcReponse rpcReponse, ByteBuf byteBuf) throws Exception {
        ResponseHeader header = rpcReponse.getHeader();
        byteBuf.writeLong(header.getRequestid());
        byteBuf.writeByte(header.getSeritype());
        byteBuf.writeByte(header.getCompresstype());
        byteBuf.writeByte(header.getCondition());
        //接收处理之后的结果
        Object content = rpcReponse.getContent();

        //如果是心跳信息，没有返回体
        if(content == null && header.getCondition() == EventType.HEART_BEAT.getValue()){
            byteBuf.writeInt(0);
            logger.info("RpcServerEncode--->heart_beat_attack");
            return;
        }
        //序列化
        Serialization serialization = SeriableUtity.getSerialization(Byte.valueOf(header.getSeritype()).intValue());
        //架构序列化之后的字节码进行压缩
        Compretor compress = CompressUtity.getCompress(Byte.valueOf(header.getCompresstype()).intValue());
        //将序列化之后的结果进行压缩，将长度写入即可
        byte[] res = compress.compress(serialization.serilize(content));
        logger.info("RpcServerEncode-->seriable->compress->{}",res);
        byteBuf.writeInt(res.length);//body_size
        //将处理之后的结果写入到客户端的channel中去
        byteBuf.writeBytes(res);
        logger.info("send data successfully!!");
    }
}
