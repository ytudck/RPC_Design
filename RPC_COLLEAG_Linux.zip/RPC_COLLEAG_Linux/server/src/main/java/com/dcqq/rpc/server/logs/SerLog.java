package com.dcqq.rpc.server.logs;

import org.slf4j.Logger;

import java.io.Serializable;

/**
 * @author duchengkun
 * @description todo
 * @date 2019-04-09 10:31
 */
public abstract class SerLog implements Serializable {

    private Logger logger ;

    public SerLog(Logger logger) {
        this.logger = logger;
    }

    public Logger getLogger() {
        return logger;
    }
    public void signlog(String message){
        beginsign(logger,message);
    }

    public abstract void beginsign(Logger logger ,String message);
}
