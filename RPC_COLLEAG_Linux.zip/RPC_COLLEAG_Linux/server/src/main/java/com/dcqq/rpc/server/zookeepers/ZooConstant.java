package com.dcqq.rpc.server.zookeepers;

/**
 * @author duchengkun
 * @description todo
 * @date 2019-04-16 16:53
 */
public class ZooConstant {
    /**
     * zookeeper的相关配置
     */
    public static final int ZK_SESSION_TIMEOUT = 5000;
    public static final  String ZK_REGISTRY_PATH = "/registry";
    public static final String ZK_DATA_PATH = ZK_REGISTRY_PATH + "/data";
}
