package com.dcqq.rpc.server;

import com.dcqq.rpc.server.codec.RpcServerDecoder;
import com.dcqq.rpc.server.codec.RpcServerEncode;
import com.dcqq.rpc.server.handler.SeverHandler;
import com.dcqq.rpc.server.logs.SerLog;
import com.dcqq.rpc.server.springhelper.SpanContextPackage;
import com.dcqq.rpc.server.zookeepers.ServiceRegsiter;
import com.dcqq.rpc.server.zookeepers.ZKCnf;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * @author duchengkun
 * @description todo
 * RPC服务端
 * @date 2019-04-08 18:57
 */
public class RpcServre extends SerLog {
    //boss thread and work thread
    private EventLoopGroup boss = new NioEventLoopGroup(1);
    private EventLoopGroup work = new NioEventLoopGroup(2);

    private ServiceRegsiter serviceRegsiter = null;

    private String serverAddress;
    private Channel channel;
    private ChannelFuture sync;

    private ZKCnf cnf = null;

    //constructor
    public RpcServre(String serverAddress) {
        super(LoggerFactory.getLogger(RpcServre.class));
        this.serverAddress = serverAddress;
    }

    //服务端启动的详细设计类
    public void start(ClassLoader loader, String scanpackagename){
        //开始扫描包
         cnf = new SpanContextPackage(loader, scanpackagename).doScanAndAet().getZKC_nf();
        //服务注册
        serviceRegsiter = new ServiceRegsiter(cnf);
        //启动相关服务
        runNettyServer();
    }

    /**
     * 我们设计的架构是使用长连接，要对connection进行复用
     */
    public void runNettyServer(){
        try{
            if(boss != null && work != null){
                ServerBootstrap bootstrap = new ServerBootstrap();
                bootstrap.group(boss,work)
                        .channel(NioServerSocketChannel.class)
                        .childHandler(new ChannelInitializer<NioSocketChannel>() {
                            @Override
                            protected void initChannel(NioSocketChannel nioSocketChannel) throws Exception {
                                //添加对应的编码和解码器
                                nioSocketChannel.pipeline()
                                        .addLast(new RpcServerDecoder())
                                        .addLast(new RpcServerEncode())
                                        .addLast(new SeverHandler());
                            }
                        }).option(ChannelOption.SO_BACKLOG,1024)
                        .childOption(ChannelOption.SO_KEEPALIVE,true);//保持长连接
                String array[] = serverAddress.split(":");
                String host = array[0];
                int port = Integer.parseInt(array[1]);
                sync = bootstrap.bind(port).sync();
                getLogger().info("server start in ip->{},port->{}",host,port);
                channel = sync.channel();
                //注册服务
                serviceRegsiter.beginRegister(this.serverAddress+":"+cnf.getServername());
                sync.addListener(new ChannelFutureListener() {
                    @Override
                    public void operationComplete(ChannelFuture channelFuture) throws Exception {
                        //当连接完成时
                        getLogger().info("------operationComplete------");
                    }
                });
                signlog("server start successfully");
                /**
                 * 即closeFuture()是开启了一个channel的监听器，
                 * 负责监听channel是否关闭的状态，如果未来监听到channel关闭了，子线程才会释放，
                 * 等待服务监听端口关闭
                 */
                channel.closeFuture().sync();
            }
        }catch (Exception e){
            getLogger().error("error ecoour in start server->{}",e);
        }finally {
            close();//关闭连接
            signlog("channel closed totally");
        }
    }

    @Override
    public void beginsign(Logger logger, String message) {
        logger.info(message);
    }

    //关闭服务
    public void close(){
        try{
            if(boss != null){
                boss.shutdownGracefully().sync();
            }
            if(work != null){
                work.shutdownGracefully().sync();
            }
        }catch (Exception e){
            getLogger().error("error come up in the process of shutwodn eventloopgroup->{}",e);
        }finally {
            signlog("shut down server peacefully");
        }
    }
}
