package com.dcqq.rpc.server.zookeepers;

import com.dcqq.rpc.server.logs.SerLog;
import org.apache.zookeeper.*;
import org.apache.zookeeper.data.Stat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.concurrent.CountDownLatch;

/**
 * @author duchengkun
 * @description todo
 * 服务注册，将本地的服务注册到zookeeper中
 * @date 2019-04-16 16:26
 */
public class ServiceRegsiter extends SerLog {

    private CountDownLatch count = new CountDownLatch(1);
    private String ip;
    private int port;
    private String dataloc;
    private ZooKeeper zooKeeper = null;


    public ServiceRegsiter(ZKCnf cnf) {
        super(LoggerFactory.getLogger(ServiceRegsiter.class));
        this.ip = cnf.getIp();
        this.port = cnf.getPort();
        this.dataloc = cnf.getDataloc();
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    /**
     * 创建的节点为临时节点,避免数据做了持久化之后的惊群效应
     * @param data
     */
    public void beginRegister(String data){
        if(data != null){
            this.zooKeeper = getServer();
            //删除注册节点
            //这一段其实可以使用shell脚本
            //deleteAllOldNode(ZooConstant.ZK_REGISTRY_PATH);
            getLogger().info("zookeeper register connect successful->{}",zooKeeper);
            if(zooKeeper != null){
                addRootNode(zooKeeper);
                createChildrenNode(zooKeeper,data);
            }
        }
    }

    /*
    删除所有的以前废弃的节点
     */
    private void deleteAllOldNode(String registerpath) {
        try{
            List<String> children = zooKeeper.getChildren(registerpath, false);
            for(String child : children){
                if(child.equals("/")){
                    deleteAllOldNode("/"+child);
                }else{
                    deleteAllOldNode(registerpath+"/"+child);
                }
            }

            //删除节点
            if(registerpath != null && !registerpath.trim().equals("/") &&
                    !registerpath.trim().startsWith("/zookeeper")){
                zooKeeper.delete(registerpath,-1);
                getLogger().warn("delete node from zookeeper->{}"+registerpath);
            }
        }catch (Exception e){
            signlog("an error occur in delete old node");
        }
    }

    /**
     * 创建孩子节点
     * @param zooKeeper
     * @param data
     */
    private void createChildrenNode(ZooKeeper zooKeeper, String data) {
        try{
            byte[] bytes = data.getBytes();
            //孩子节点创建的是持久化的节点
            zooKeeper.create(ZooConstant.ZK_REGISTRY_PATH+"/"+this.dataloc+"/data",bytes,
                    ZooDefs.Ids.OPEN_ACL_UNSAFE,CreateMode.PERSISTENT_SEQUENTIAL);
        }catch (Exception e){
            getLogger().error("error occour inServiceRegsiter->createChildrenNode->{}",e);
        }finally {
            //增加对应的日志操作
            signlog("createChildrenNode sucessfully");
        }
    }

    /**
     * 创建根节点
     * @param zooKeeper
     */
    private void addRootNode(ZooKeeper zooKeeper) {
        try{
            Stat stat = zooKeeper.exists(ZooConstant.ZK_REGISTRY_PATH,false);
            //根节点创建的是持久化节点
            if(stat == null){
                zooKeeper.create(ZooConstant.ZK_REGISTRY_PATH,new byte[0],
                        ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.PERSISTENT);
                zooKeeper.create(ZooConstant.ZK_REGISTRY_PATH+"/"+this.dataloc,new byte[0],
                        ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.PERSISTENT);
            }


        }catch (Exception e){
            getLogger().error("error occour inServiceRegsiter->addRootNode->{}",e);
        }finally {
            //增加相关的日志操作
            signlog("addRootNode sucessfully");
        }
    }

    /**
     * 连接zookeeper服务
     * @return
     */
    private ZooKeeper getServer() {
        ZooKeeper zooKeeper = null;
        try{
            //regsiteraddress
            zooKeeper = new ZooKeeper(ip+":"+port,ZooConstant.ZK_SESSION_TIMEOUT,
                    (WatchedEvent event)->{
                if(event.getState() == Watcher.Event.KeeperState.SyncConnected){
                    count.countDown();
                }
            });
            count.await();
        }catch (Exception e){
            getLogger().error("error occour inServiceRegsiter->getServer->{}",e);
            e.printStackTrace();
        }finally {
            //增加日志操作
            signlog("get server successful");
        }
        return zooKeeper;
    }

    /**
     * info级别的log
     * @param logger
     * @param message
     */
    @Override
    public void beginsign(Logger logger, String message) {
        logger.info(message);
    }
}
