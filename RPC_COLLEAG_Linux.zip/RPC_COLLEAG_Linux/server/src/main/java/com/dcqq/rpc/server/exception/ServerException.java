package com.dcqq.rpc.server.exception;

/**
 * @author duchengkun
 * 自定义异常类
 * @description todo
 * @date 2019-05-05 14:32
 */
public class ServerException extends Throwable{
    public ServerException() {
    }

    public ServerException(String message) {
        super(message);
    }

    public ServerException(String message, Throwable cause) {
        super(message, cause);
    }
}
