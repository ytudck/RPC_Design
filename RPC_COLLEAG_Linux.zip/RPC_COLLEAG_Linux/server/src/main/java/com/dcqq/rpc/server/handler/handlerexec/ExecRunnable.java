package com.dcqq.rpc.server.handler.handlerexec;

import com.dcqq.rpc.protocol.HttpParam.RequestBody;
import com.dcqq.rpc.protocol.HttpParam.ResponseHeader;
import com.dcqq.rpc.protocol.HttpParam.RpcReponse;
import com.dcqq.rpc.protocol.HttpParam.RpcResquest;
import com.dcqq.rpc.server.logs.SerLog;
import io.netty.channel.ChannelHandlerContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.CountDownLatch;

//执行回调接口(用来异步执行服务的响应结果)
public class ExecRunnable extends SerLog implements Runnable {

    private ChannelHandlerContext channelHandlerContext;
    private RpcResquest<RequestBody> resquest;

    public ExecRunnable(RpcResquest resquest,ChannelHandlerContext channelHandlerContext) {
        super(LoggerFactory.getLogger(ExecRunnable.class));
        this.resquest = resquest;
        this.channelHandlerContext = channelHandlerContext;
    }

    @Override
    public void run() {
        CountDownLatch latch = new CountDownLatch(1);
        Object result = null;
        String methodname = resquest.getContent().getMethodname();
        Object[] params = resquest.getContent().getParams();
        String servicename = resquest.getContent().getServicename();
        Class<?>[] paramsType = resquest.getContent().getParamsType();
        getLogger().info("methodname->{},params->{},servicename->{}",methodname,params,servicename);
        try{
            //执行方法，回调
            result = InvokeMachine.getinstance().exec(methodname,servicename,params,paramsType,latch);
            latch.await();
            signlog("invoke result->"+result);
            //对执行的结果封装，并将结果写入到channel的管道中
            RpcReponse<Object> response = new RpcReponse<Object>();
            ResponseHeader header = new ResponseHeader(resquest.getHeader().getRequestid(),
                    resquest.getHeader().getSeritype(),
                    resquest.getHeader().getCompresstype(),
                    //默认的bodysize为0(设计存在缺陷，需要优化)
                    resquest.getHeader().getCondition(),0);
            response.setHeader(header);
            response.setContent(result);
            signlog("packageing response ->{}"+response.toString());
            //将结果写入channel  ByteBuf(这个是处理结果的关键)  向client写入相关内容
            channelHandlerContext.writeAndFlush(response);
        }catch (Exception e){
            //日志收集,将错误的日志输出
            getLogger().error("invole error->{}",e);
        }finally {
            //要及时关闭资源，可以提高性能
        }
    }

    /**
     * info-->level
     * @param logger
     * @param message
     */
    @Override
    public void beginsign(Logger logger, String message) {
        logger.info(message);
    }
}
