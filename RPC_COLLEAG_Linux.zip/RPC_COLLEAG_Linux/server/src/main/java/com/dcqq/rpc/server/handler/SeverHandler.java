package com.dcqq.rpc.server.handler;

import com.dcqq.rpc.protocol.HttpParam.RequestBody;
import com.dcqq.rpc.protocol.HttpParam.RpcResquest;
import com.dcqq.rpc.server.constant.EventType;
import com.dcqq.rpc.server.handler.handlerexec.ExecRunnable;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.Executor;
import java.util.concurrent.LinkedTransferQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;


/**
 * @author duchengkun
 * server端的类处理器
 * @description todo
 * @date 2019-04-09 11:30
 */
public class SeverHandler extends SimpleChannelInboundHandler<RpcResquest<RequestBody>> {
    //log操作
    private Logger logger = LoggerFactory.getLogger(SeverHandler.class);

    //线程池,使用线程池去处理请求
    private static Executor executor = new ThreadPoolExecutor(20,
            40,
            10*1000,
            TimeUnit.MILLISECONDS,
            //这个阻塞队列可以提高线程性能(参考Tomcat源码)
            new LinkedTransferQueue<Runnable>());

    /**
     * 在这里进行具体的业务逻辑处理
     * @param channelHandlerContext
     * @param rpcResquest
     * @throws Exception
     */
    @Override
    protected void channelRead0(ChannelHandlerContext channelHandlerContext, RpcResquest<RequestBody> rpcResquest) throws Exception {
        //如果是心跳信息，分类进行处理
        logger.info("receive data from client after seriable and unpress->{}",rpcResquest);
        byte condition = rpcResquest.getHeader().getCondition();
        if(EventType.HEART_BEAT.getValue() == condition){//如果是心跳包
            //将请求直接返回
            channelHandlerContext.writeAndFlush(rpcResquest);
            logger.info("this is a heart_test_package");
            return;
        }
        //获取请求内容
        RequestBody content = rpcResquest.getContent();
        logger.info("the RequestBody from client is ->{}",content);
        logger.info("the contents of RequestBody :servicename->{},methodname->{},params->{},paramsType->{}",
                content.getServicename(),content.getMethodname(),content.getParams(),content.getParamsType());
        if(StringUtils.isNotEmpty(content.getServicename())){
            logger.info("beg in execute!!");
            executor.execute(new ExecRunnable(rpcResquest,channelHandlerContext));
        }

    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        super.exceptionCaught(ctx, cause);
        ctx.pipeline().close().addListener((ChannelFuture channelFuture)->{
            //增加日志操作，或者断线重连
            //打印日志
            logger.error("error invoke handler->{}",cause);
        });
    }


}
