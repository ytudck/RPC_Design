package com.dcqq.rpc.server;

/**
 * @author duchengkun
 * @description todo
 * 这个是启动类
 * @date 2019-04-08 19:02
 */
public class App {
//    public static void main(String args[]){
//
//    }
}
