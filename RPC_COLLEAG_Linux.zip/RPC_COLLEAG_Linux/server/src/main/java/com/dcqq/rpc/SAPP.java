package com.dcqq.rpc;

import com.dcqq.rpc.server.RpcServre;
import com.dcqq.rpc.server.springhelper.SpanContextPackage;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author duchengkun
 * @description todo
 * @date 2019-04-08 18:51
 */
public class SAPP {

    /**
     *相当于服务的入口类
     */
    public static void RPC_SEERVER(String serveraddress, ClassLoader loader, String packagename,
                                   ConcurrentHashMap<String,Class<?>> result){
        //开启rpc服务
        SpanContextPackage.setResult(result);
        RpcServre rpcServre = new RpcServre(serveraddress);
        rpcServre.start(loader,packagename);
    }
}
