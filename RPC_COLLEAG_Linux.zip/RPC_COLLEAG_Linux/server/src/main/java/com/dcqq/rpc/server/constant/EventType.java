package com.dcqq.rpc.server.constant;

/**
 * 表明请求的类型,正常请求--心跳检测
 */
public enum EventType {
    //正常请求
    NORMAL((byte)1),
    //心跳请求
    HEART_BEAT((byte)2);

    private byte value;

    EventType(byte value) {
        this.value = value;
    }

    public byte getValue() {
        return value;
    }

    public void setValue(byte value) {
        this.value = value;
    }
}
