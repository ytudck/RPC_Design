package com.dcqq.rpc.server.codec;

import com.dcqq.rpc.protocol.HttpParam.RequestBody;
import com.dcqq.rpc.protocol.HttpParam.RequestHeader;
import com.dcqq.rpc.protocol.HttpParam.RpcResquest;
import com.dcqq.rpc.seriable.enums.CompressUtity;
import com.dcqq.rpc.seriable.enums.SeriableUtity;
import com.dcqq.rpc.seriable.interfaces.Compretor;
import com.dcqq.rpc.seriable.interfaces.Serialization;
import com.dcqq.rpc.server.constant.EventType;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * @author duchengkun
 * @description 解码器
 * @date 2019-04-09 10:41
 */
public class RpcServerDecoder extends ByteToMessageDecoder {

    //logger
    private Logger logger = LoggerFactory.getLogger(RpcServerDecoder.class);
    /**
     *根据自定义的网络协议进行解码
     * @param channelHandlerContext
     * @param byteBuf
     * @param list
     * @throws Exception
     */

    @Override
    protected void decode(ChannelHandlerContext channelHandlerContext,
                          ByteBuf byteBuf, List<Object> list) throws Exception {
        if(byteBuf.readableBytes() < 15){//此时发生了丢包现象（固定头部为15个字节）
            logger.error("discard tcp package is taking place");
            return;
        }
        //标记读索引
        byteBuf.markReaderIndex();
        //请求id
        long requestid = byteBuf.readLong();
        //序列化方式
        byte seritype = byteBuf.readByte();
        //压缩方式
        byte compresstype = byteBuf.readByte();
        //心跳，正常请求
        byte condition = byteBuf.readByte();
        //请求体
        int bodysize = byteBuf.readInt();
        //请求体
        Object request_body = null;
        logger.info("requestid->{},seritype->{},compresstype->{},condition->{},bodysize->{}",
                requestid,seritype,compresstype,condition,bodysize);
        //判断是否是心跳检测包(这个机制是保证连接稳定的基本手段)
        if(bodysize !=0 && (EventType.HEART_BEAT.getValue() != condition)){
             //非心跳检测包
            if(byteBuf.readableBytes() < bodysize){//此时发生了丢包
                //重置byteBuf读索引位置
                byteBuf.resetReaderIndex();
                return;
            }

            //接收字节
            byte[] result = new byte[bodysize];
            byteBuf.readBytes(result);
            //获取压缩方式
            Serialization serialization = SeriableUtity.getSerialization(Byte.valueOf(seritype).intValue());
            Compretor compress = CompressUtity.getCompress(Byte.valueOf(compresstype).intValue());
            //解析请求体中的内容
            request_body = serialization.descerilize(compress.decompress(result), RequestBody.class);
            logger.info("after uncompress and deseriable the final request_body->{}",request_body);
        }
        //对结果集进行封装
        RequestHeader header = new RequestHeader(requestid,seritype,compresstype,condition,bodysize);
        RpcResquest resquest = new RpcResquest(header,request_body);
        list.add(resquest);
    }

}
