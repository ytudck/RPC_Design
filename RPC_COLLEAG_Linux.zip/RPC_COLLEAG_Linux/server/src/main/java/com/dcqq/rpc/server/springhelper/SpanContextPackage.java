package com.dcqq.rpc.server.springhelper;

import com.dcqq.rpc.server.handler.handlerexec.InvokeMachine;
import com.dcqq.rpc.server.logs.SerLog;
import com.dcqq.rpc.server.zookeepers.ZKCnf;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author duchengkun
 * 包扫描机制
 * @description todo
 * @date 2019-04-15 18:48
 */
public class SpanContextPackage extends SerLog {
    //设计一个包扫描算法
    //并且进行各种初始化的工作
    private String base_package_name;
    //类加载器
    private ClassLoader loader;
    //是否是web项目的标识
    private boolean isweb = true;
    //用于存放最后的结果集
    private static ConcurrentHashMap<String,Class<?>> result = null;
    //扫描的类名称
    private List<String> scannames = new ArrayList<>();

    static {
        result = new ConcurrentHashMap<String,Class<?>>();
    }

    //关于自动扫描包的相关配置
    public SpanContextPackage(ClassLoader loader,String name) {
        super(LoggerFactory.getLogger(SpanContextPackage.class));
        try{
            this.loader = loader;
            if(StringUtils.isNotEmpty(name)){
                this.base_package_name = name;
                this.isweb = false;
            }else{
                //获取跟包扫描值
                InputStream rs = loader.getResourceAsStream("config/package.properties");
                Properties properties = new Properties();
                properties.load(rs);
                this.base_package_name =  properties.getProperty("basepackage");
            }
            signlog("the base package name is ->"+base_package_name);
            //beginScan(base_package_name);
        }catch (Exception e){
            getLogger().error("error occour in constructor of SpanContextPackage ->{}",e);
        }finally {
            //日志操作
            signlog("constructor is finished");
            getLogger().info("basepackagename->{}",this.base_package_name);
        }
    }


    /**
     * 扫描包   windows系统兼容
     */
    public SpanContextPackage beginScan(String packagename){
        signlog("begin scan base package");
        URL url = null;
        if(isweb){
            url = this.loader.getResource(packagename.replaceAll("\\.","/"));
        }else{
            url = this.loader.getResource(packagename.replaceAll("\\.","/"));
        }
        getLogger().info("the url is ->{}",url);
        File file = new File(url.getFile());
        for(File f : file.listFiles()){
            if(f.isDirectory()){
                beginScan(packagename+"."+f.getName());
            }else{
                scannames.add(packagename+"."+f.getName().replace(".class","").trim());
                getLogger().info("scanbasepackage-->{}",packagename+"."+f.getName().replace(".class","").trim());
            }
        }
        return this;
    }



    /**
     * bean装配
     */
    public SpanContextPackage doScanAndAet(){
        try{
            InvokeMachine.getinstance().setResult_map(result);
        }catch (Exception e){
            signlog("the resultmasp is set successfully");
        }
        return this;
    }

    /**
     * 获得zookeeper配置
     * @return
     */
    public ZKCnf getZKC_nf(){
        ZKCnf cnf = new ZKCnf();
        try{
            InputStream inputStream = this.loader.getResourceAsStream("config/zkcnf.properties");
            Properties properties = new Properties();
            properties.load(inputStream);
            cnf.setIp(properties.getProperty("ip").trim());
            cnf.setPort(Integer.parseInt(properties.getProperty("port").trim()));
            cnf.setDataloc(properties.getProperty("datapath").trim());
            cnf.setServername(properties.getProperty("servergroup").trim());
        }catch (Exception e){
            getLogger().error("get zookeeper cnf occur an error->{}",e);
        }
        signlog("get zookeeper properties successfuly ip->"+cnf.getIp()+" ,port->"+cnf.getPort()+" ,servergroup->"+cnf.getServername());
        return cnf;
    }


    @Override
    public void beginsign(Logger logger, String message) {
        logger.info(message);
    }

    public static ConcurrentHashMap<String, Class<?>> getResult() {
        return result;
    }

    public static void setResult(ConcurrentHashMap<String, Class<?>> result) {
        SpanContextPackage.result = result;
    }
}
