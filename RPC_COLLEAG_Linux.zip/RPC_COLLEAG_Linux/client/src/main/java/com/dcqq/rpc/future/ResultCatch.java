package com.dcqq.rpc.future;

import com.dcqq.rpc.clilog.CliLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.CountDownLatch;

/**
 * @author duchengkun
 * 获取具体的返回结果
 * @description todo
 * @date 2019-04-17 11:41
 */

public class ResultCatch<T> extends CliLog implements ResultFuture<T> {
    //存放本次调用的结果
    private T message;
    //线程之间的同步
    private CountDownLatch latch;


    //constructor
    public ResultCatch() {
        super(LoggerFactory.getLogger(ResultCatch.class));
    }

    //set
    public void setMessage(T message) {
        try{
            this.message = message;
            latch.countDown();//set value,notify the waitting thread
        }finally {

        }
    }

    public void setLatch(CountDownLatch latch) {
        this.latch = latch;
    }

    /**
     * 记录info级别地日志
     * @param logger
     * @param msg
     */
    @Override
    public void gisnLog(Logger logger, String msg) {
        logger.info(msg);
    }

    /**
     * 模仿JDK中的Future接口
     * @return
     */
    @Override
    public T getData() {
        try{
            return this.message;
        }finally {
        }
    }
}
