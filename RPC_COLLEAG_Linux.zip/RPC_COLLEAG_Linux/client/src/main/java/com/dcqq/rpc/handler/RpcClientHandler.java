package com.dcqq.rpc.handler;

import com.dcqq.rpc.future.ResponseFuture;
import com.dcqq.rpc.future.SyncExcutors;
import com.dcqq.rpc.messagedec.ClientEventType;
import com.dcqq.rpc.pool.Connection;
import com.dcqq.rpc.pool.NettyConnectionPoolFactory;
import com.dcqq.rpc.protocol.HttpParam.RpcReponse;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.InetSocketAddress;


/**
 * @author duchengkun
 * @description todo  客户端的适配处理
 * 处理服务端返回的结果请求
 * @date 2019-04-19 10:52
 */
public class RpcClientHandler extends SimpleChannelInboundHandler<RpcReponse<Object>> {

    private Logger logger = LoggerFactory.getLogger(RpcClientHandler.class);


    @Override
    protected void channelRead0(ChannelHandlerContext channelHandlerContext, RpcReponse<Object> rpcReponse) throws Exception {
        //从请求对象的容器中移除
        ResponseFuture<Object> already_remove = Connection.result_map.remove(rpcReponse.getHeader().getRequestid());

        if(already_remove == null){//连接超时
            logger.warn("the connecting is timeout!!");
        }
        //是否是心跳消息,心跳的消息类型
        if(rpcReponse.getHeader().getCondition() == ClientEventType.HEART_BEAT.getValue()
                && rpcReponse.getHeader().getBodysize() == 0){//body_size = 0
            //不做处理，以后功能扩展时可以做统计，搜集，以及断线重连之类
            logger.info("receive data from server ipaddress->{}",
                    channelHandlerContext.channel().remoteAddress());
        }else{
            //对从服务端获取的结果进行异步的处理
            SyncExcutors.exec(()->{
                already_remove.getResultCatch().setMessage(rpcReponse.getContent());
                logger.info("receive and set value successfully!!");
                logger.info("the thread pool CorePoolSize is =>{}",SyncExcutors.getExecutor().getCorePoolSize());
                //这是一个大致的结果，并不是精确的结果
                logger.info("the thread pool ActiveCount is =>{}",SyncExcutors.getExecutor().getActiveCount());
                logger.info("the thread pool currentThread is =>{}",SyncExcutors.getExecutor().getPoolSize());
                logger.info("the thread pool compeleteTask is =>{}",SyncExcutors.getExecutor().getCompletedTaskCount());
                logger.info("核心线程空闲超时是否关闭:" + SyncExcutors.getExecutor().allowsCoreThreadTimeOut());//核心线程空闲超时是否关闭:false
            });
        }

    }

    /**
     * 读取数据超时的时候调用
     * @param ctx
     * @param evt
     * @throws Exception
     */
    @Override
    public void userEventTriggered(ChannelHandlerContext ctx, Object evt){
        logger.error("client is receive data from server is totally timeout");
        try{
            throw new Exception("an error occur in server provider ,please make sure you have all the channel active!");
        }catch (Exception e){e.printStackTrace();}
    }

    /**
     * when the channel was actived
     * @param ctx
     * @throws Exception
     */
    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        super.channelActive(ctx);
        logger.info("channel is activing now ");
    }

    /**
     * when the error occured
     * channel关闭时添加关闭事件这个方法，将该节点剔除。
     * 当某一台服务宕机的时候，要回调
     * @param ctx
     * @param cause
     * @throws Exception
     */
    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        super.exceptionCaught(ctx, cause);

        ctx.channel().close().addListener((ChannelFuture channelFuture)->{
            logger.info("channel close from address:{}",channelFuture.channel().remoteAddress());
            InetSocketAddress inetSocketAddress =
                    (InetSocketAddress) channelFuture.channel().remoteAddress();
            String ip = inetSocketAddress.getAddress().getHostAddress();//ip
            int port = inetSocketAddress.getPort();//端口
            //remove from channel poll factory
            NettyConnectionPoolFactory.connection_map.remove(ip+":"+port);
            NettyConnectionPoolFactory.connection_ip_group.remove(ip+":"+port);
        });
    }



}
