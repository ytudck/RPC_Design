package com.dcqq.rpc;

import com.dcqq.rpc.proxy.RpcProxyFactory;
import com.dcqq.rpc.zookeeper.CliZookeeperDiscover;

import java.util.List;

/**
 * @author duchengkun
 * @description todo
 * @date 2019-04-17 11:08
 */
public class CApp {
    /**
     * 客户端启动服务的类
     * @param loader
     */
    public static void RUN_CLIENT(ClassLoader loader,String dataName){
        //服务发现
        CliZookeeperDiscover discover = new CliZookeeperDiscover(loader,dataName);
        //获取暴露的服务地址列表
        List<String> zook_data_list = discover.getZook_data_list();
        for(String address : zook_data_list){
            String ip = address.split(":")[0];
            int port = Integer.parseInt(address.split(":")[1]);
            //服务组名称
            String group_server_name = address.split(":")[2];
            NettyClient client  = new NettyClient(ip,port,group_server_name);
        }
    }


    /**
     * 对于接口的动态代理
     * @param intreface
     * @param <T>
     * @return
     */
    public static  <T> T createProxyForm(Class<T> intreface,String name){
        return RpcProxyFactory.form(intreface,name);
    }

}
