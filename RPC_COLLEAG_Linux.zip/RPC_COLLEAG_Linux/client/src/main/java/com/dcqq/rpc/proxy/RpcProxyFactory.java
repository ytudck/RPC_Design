package com.dcqq.rpc.proxy;

import com.dcqq.rpc.clilog.CliLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Closeable;
import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.Proxy;

/**
 * @author duchengkun
 * @description todo
 * 创造代理工厂的工具类
 * @date 2019-04-22 18:22
 */
public class RpcProxyFactory extends CliLog implements Serializable, Closeable {
    public RpcProxyFactory() {
        super(LoggerFactory.getLogger(RpcProxyFactory.class));
    }

    //form a proxy interface
    public static <T> T form(Class<T> interfaces,String name){
        return (T)Proxy.newProxyInstance(interfaces.getClassLoader(),
                new Class<?>[]{interfaces},new ObjectProxy<T>(interfaces,name));
    }

    @Override
    public void gisnLog(Logger logger, String msg) {
        logger.info(msg);
    }

    @Override
    public void close() throws IOException { }
}
