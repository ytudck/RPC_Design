package com.dcqq.rpc.config;

import com.dcqq.rpc.clilog.CliLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author duchengkun
 * @description todo
 * @date 2019-04-23 15:10
 */
public class Byte2IntService extends CliLog {
    public Byte2IntService() {
        super(LoggerFactory.getLogger(Byte2IntService.class));
    }

    /*
    byte  转化为 int
     */
    public static int byte2int(byte var1){
        return (int)var1;
    }

    public static int byte1int(byte var2){
        return (int)(var2 & 0xff);
    }

    /*
    int  转化  byte
     */

    public static byte int1byte(int var1){
        //强制类型转换   此种情况要求int不可以>255
        return (byte) var1;
    }

    /**
     *
     * @param logger
     * @param msg
     */
    @Override
    public void gisnLog(Logger logger, String msg) {
        logger.info(msg);
    }
}
