package com.dcqq.rpc.messagedec;

public enum  ClientEventType {
    //正常请求
    NORMAL((byte)0),
    //心跳请求
    HEART_BEAT((byte)(1<<6));

    private byte value;

    private ClientEventType(byte value) {
        this.value = value;
    }

    public byte getValue() {
        return value;
    }

    public void setValue(byte value) {
        this.value = value;
    }
}

