package com.dcqq.rpc.exception;

/**
 * @author duchengkun
 * 自定义异常(客户端异常)
 * @description todo
 * @date 2019-05-05 14:35
 */
public class CliException extends Throwable{

    public CliException() {
    }

    public CliException(String message) {
        super(message);
    }

    public CliException(String message, Throwable cause) {
        super(message, cause);
    }
}
