package com.dcqq.rpc.future;

import io.netty.channel.ChannelFuture;

import java.util.concurrent.CountDownLatch;

/**
 * @author duchengkun
 * @description todo
 * 处理服务端返回结果的future
 * @date 2019-04-25 10:27
 */
public class ResponseFuture<T> {
    //catch result
    private ResultCatch<T> resultCatch;
    //fututre
    private ChannelFuture future;
    //timeout
    private long timeout;

    private CountDownLatch latch;

    public ResponseFuture(ResultCatch<T> resultCatch, ChannelFuture future, long timeout,CountDownLatch latch) {
        this.resultCatch = resultCatch;
        this.future = future;
        this.timeout = timeout;
        this.latch = latch;
        //线程同步标志
        this.resultCatch.setLatch(latch);
    }

    public ResultCatch<T> getResultCatch() {
        return resultCatch;
    }

    public void setResultCatch(ResultCatch<T> resultCatch) {
        this.resultCatch = resultCatch;
    }
}
