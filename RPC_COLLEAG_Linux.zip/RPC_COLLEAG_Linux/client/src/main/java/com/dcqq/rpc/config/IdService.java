package com.dcqq.rpc.config;

import com.dcqq.rpc.clilog.CliLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReentrantLock;

/**
 * @author duchengkun
 * @description todo
 * @date 2019-04-22 18:52
 */
public class IdService extends CliLog {

    //init  操作的原子性
    private static AtomicLong atomicLong = new AtomicLong(0l);

    //存放于堆中
    private static ReentrantLock reentrantLock = new ReentrantLock(true);

    public IdService() {
        super(LoggerFactory.getLogger(IdService.class));
    }

    //添加同步机制
    public static Long getId(){
        reentrantLock.lock();
        try{
            //automic
            return atomicLong.addAndGet(1);
        }finally {
            reentrantLock.unlock();
        }
    }

    @Override
    public void gisnLog(Logger logger, String msg) {
        logger.info(msg);
    }
}
