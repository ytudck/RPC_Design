package com.dcqq.rpc.pool;

import org.apache.commons.pool2.KeyedPooledObjectFactory;
import org.apache.commons.pool2.impl.GenericKeyedObjectPool;
import org.apache.commons.pool2.impl.GenericKeyedObjectPoolConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author duchengkun
 * @description todo
 * 基于commons-pools2进一步封装的连接池(Channel-->Connection)
 * @date 2019-04-18 19:06
 */
public class NettyConnectionPool extends GenericKeyedObjectPool<String,Connection> {

    //logger
    private Logger logger = LoggerFactory.getLogger(NettyConnectionPool.class);

    public NettyConnectionPool(KeyedPooledObjectFactory<String, Connection> factory) {
        super(factory);
    }

    public NettyConnectionPool(KeyedPooledObjectFactory<String, Connection> factory, GenericKeyedObjectPoolConfig<Connection> config) {
        super(factory, config);
    }
}
