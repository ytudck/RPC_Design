package com.dcqq.rpc.pool;

import com.dcqq.rpc.clilog.CliLog;
import com.dcqq.rpc.future.ResponseFuture;
import com.dcqq.rpc.future.ResultCatch;
import com.dcqq.rpc.protocol.HttpParam.RpcResquest;
import io.netty.channel.ChannelFuture;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Closeable;
import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * @author duchengkun
 * @description todo
 * 这个是专门用来处理连接的类
 * 将连接进一步的进行抽象处理
 * 想办法对这个connection进行复用
 * @date 2019-04-17 20:20
 */
public class Connection extends CliLog implements Closeable {
    //netty channel
    private ChannelFuture future;
    //服务组
    private String server_gtorp_name;
    //原子操作类
    private AtomicBoolean isConnected = new AtomicBoolean();
    private static final AtomicLong id = new AtomicLong(0);

    //用来存放回调函数(异步回调，放在线程池里面去跑)
    public static final ConcurrentHashMap<Long, ResponseFuture<Object>> result_map;
    //weight(权重)
    private AtomicLong re_factor = new AtomicLong(0l);

    static {
        result_map = new ConcurrentHashMap<Long, ResponseFuture<Object>>();
    }

    //constructor
    public Connection() {
        super(LoggerFactory.getLogger(Connection.class));
        this.isConnected.set(false);
        this.future = null;
    }

    public ChannelFuture getFuture() {
        return future;
    }

    public void setFuture(ChannelFuture future) {
        this.future = future;
    }

    public boolean getIsConnected() {
        return isConnected.get();
    }

    public void setIsConnected(boolean isConnected) {
        this.isConnected.set(isConnected);
    }

    public long getRe_factor() {
        return re_factor.get();
    }

    public String getServer_gtorp_name() {
        return server_gtorp_name;
    }

    public void setServer_gtorp_name(String server_gtorp_name) {
        this.server_gtorp_name = server_gtorp_name;
    }

    /**
     * 想服务端发送请求
     * @param request
     * @param timeout
     * @param latch
     * @return
     */
    public ResultCatch<Object> send_request(RpcResquest request, long timeout,
                                            CountDownLatch latch,CountDownLatch main_latch) throws Exception {
        if(!getIsConnected()){
            throw new Exception("this connection is discard");
        }
        //log当前connection的权值
        signLog("use connection"+this.future.channel().remoteAddress().toString());
        request.getHeader().setRequestid(id.incrementAndGet());
        //发送请求的时候将返回的结果集进行封装
        ResponseFuture<Object> responseFuture = new ResponseFuture<Object>(new ResultCatch<Object>(),
                this.future,1000l,latch);
        //放入到结果集容器中
        result_map.put(request.getHeader().getRequestid(),responseFuture);
        try{
            //发送信息(向服务端发送数据)
            future.channel().writeAndFlush(request);
        }catch (Exception e){
            //请求失败
            e.printStackTrace();
            //将该请求从容器中剔除
            result_map.remove(request.getHeader().getRequestid());

        }finally {
            //发送完请求之后要将权重加1
            long l = re_factor.addAndGet(1l);
            signLog("the re_factor"+this.future.channel().remoteAddress().toString()+" total is "+l);
        }
        //将请求的结果返回
        boolean await = latch.await(4, TimeUnit.SECONDS);

        if(!await){//超时
            try{//如果不捕获异常的话，下面的代码就不会正常执行，导致程序一直阻塞。
                throw new Exception("waitting the response timeout");
            }catch (Exception e){ e.printStackTrace(); }
        }
        //释放线程之间的信号标志
        main_latch.countDown();
        return responseFuture.getResultCatch();
    }



    /**
     * close channel stream
     * @throws IOException
     */
    @Override
    public void close() throws IOException {
        future.channel().close();
        signLog("close the client channel successfully");
    }

    /**
     * log
     * @param logger
     * @param msg
     */
    @Override
    public void gisnLog(Logger logger, String msg) {
        logger.info(msg);
    }
}
