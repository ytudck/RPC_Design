package com.dcqq.rpc.pool;

import com.dcqq.rpc.clilog.CliLog;
import org.apache.commons.pool2.KeyedPooledObjectFactory;
import org.apache.commons.pool2.PooledObject;
import org.apache.commons.pool2.impl.DefaultPooledObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author duchengkun
 * @description todo
 * key  ->  value
 * Netty连接的对象池工厂
 * @date 2019-04-18 19:13
 */
public class NettyConnectionPoolFactory extends CliLog implements KeyedPooledObjectFactory<String,Connection> {


    //ip:port  ->  connection
    public static ConcurrentHashMap<String,Connection> connection_map ;

    public static ConcurrentHashMap<String,String>  connection_ip_group;
    //它当且仅当在类初次加载时会被初始化
    static {
        connection_map = new ConcurrentHashMap<String,Connection>();
        connection_ip_group = new ConcurrentHashMap<String,String>();
    }

    //获取map中所有的key
    public static List<String> getKeySets(){
        Enumeration<String> keys = connection_map.keys();
        List<String> result = new ArrayList<String>();
        while (keys.hasMoreElements()){
            result.add(keys.nextElement());
        }
        return result;
    }
    /**
     * 用来创建池对象,
     * 将不用的池对象进行钝化(passivateObject),
     * 对要使用的池对象进行激活(activeObject),
     * 对池对象进行验证(validateObject),
     * 对有问题的池对象进行销毁(destroyObject)等工作。
     */

    public NettyConnectionPoolFactory() {
        super(LoggerFactory.getLogger(NettyConnectionPoolFactory.class));
    }

    /**
     * 传入的s，在代理层进行了一个负载均衡的处理
     * @param s
     * @return
     * @throws Exception
     */
    @Override
    public PooledObject<Connection> makeObject(String s) throws Exception {
        //负载均衡原理获取连接
        return new DefaultPooledObject<>(connection_map.get(s));
    }

    /**
     * 销毁对象,当这个链接废弃时，就将其关闭
     * @param s
     * @param pooledObject
     * @throws Exception
     */
    @Override
    public void destroyObject(String s, PooledObject<Connection> pooledObject) throws Exception {
        //关闭流通道
        pooledObject.getObject().close();
    }

    /**
     * 验证对象
     * @param s
     * @param pooledObject
     * @return
     */
    @Override
    public boolean validateObject(String s, PooledObject<Connection> pooledObject) {
        Connection connection = connection_map.get(s);
        boolean isconnected = connection.getIsConnected();//is connected
//        boolean future_open = connection.getFuture().channel().isOpen();// is open
//        boolean channel_active = connection.getFuture().channel().isActive();// is active
        //return result-->boolean
        return isconnected;
    }

    /**
     * 对要使用的池对象进行激活
     * @param s
     * @param pooledObject
     * @throws Exception
     */
    @Override
    public void activateObject(String s, PooledObject<Connection> pooledObject) throws Exception { }

    /**
     *将不用的池对象进行钝化
     * @param s
     * @param pooledObject
     * @throws Exception
     */
    @Override
    public void passivateObject(String s, PooledObject<Connection> pooledObject) throws Exception { }

    /**
     * in order to unify all logger gather system
     * @param logger
     * @param msg
     */
    @Override
    public void gisnLog(Logger logger, String msg) {
        logger.info(msg);
    }

}
