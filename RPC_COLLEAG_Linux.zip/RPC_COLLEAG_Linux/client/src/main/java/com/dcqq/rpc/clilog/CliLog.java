package com.dcqq.rpc.clilog;

import org.slf4j.Logger;

import java.io.Serializable;

/**
 * @author duchengkun
 * @description todo
 * @date 2019-04-17 11:20
 */
public abstract class CliLog implements Serializable {
    private Logger logger;

    public CliLog(Logger logger) {
        this.logger = logger;
    }

    public Logger getLogger() {
        return logger;
    }

    public void setLogger(Logger logger) {
        this.logger = logger;
    }

    public void signLog(String msg){
        gisnLog(logger,msg);
    }

    //开始记录日志
    public abstract void gisnLog(Logger logger,String msg);
}
