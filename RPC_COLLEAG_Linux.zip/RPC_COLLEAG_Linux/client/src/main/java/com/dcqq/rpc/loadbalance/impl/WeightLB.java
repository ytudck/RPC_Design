package com.dcqq.rpc.loadbalance.impl;

import com.dcqq.rpc.clilog.CliLog;
import com.dcqq.rpc.loadbalance.LoadBalnce;
import com.dcqq.rpc.pool.Connection;
import com.dcqq.rpc.pool.NettyConnectionPoolFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * @author duchengkun
 * @description todo
 * 根据权重来分配(最少连接数法)
 * @date 2019-04-23 18:48
 */
public class WeightLB extends CliLog implements LoadBalnce {

    //constructor
    public WeightLB() {
        super(LoggerFactory.getLogger(WeightLB.class));
    }

    @Override
    public void gisnLog(Logger logger, String msg) {
        logger.info(msg);
    }


    /**
     * 最小权重法,获取连接数最小的连接进行匹配
     * @param data
     * @return
     */
    @Override
    public String  compare(List<String> data,String name) {
        List<String> ip_reflect = new ArrayList<String>();
        String url_targer = null;
        for(Map.Entry<String,String> entry : NettyConnectionPoolFactory.connection_ip_group.entrySet()){
            if(name.equals(entry.getValue())){
                //获得该服务组所有的ip
                ip_reflect.add(entry.getKey());
                signLog("the server group"+name+" the contains ip is"+entry.getKey());
            }
        }
        //根据该服务组的ip进行服务的调用
        long target_value = NettyConnectionPoolFactory.connection_map.get(ip_reflect.get(0)).getRe_factor();
        url_targer = ip_reflect.get(0);
        signLog("the first target value is "+target_value);
        for(String key : ip_reflect){
            Connection connection = NettyConnectionPoolFactory.connection_map.get(key);
            if(connection.getRe_factor() < target_value){
                target_value = connection.getRe_factor();
                url_targer = key;
            }
        }
        //IP port
        return url_targer;
    }
}
