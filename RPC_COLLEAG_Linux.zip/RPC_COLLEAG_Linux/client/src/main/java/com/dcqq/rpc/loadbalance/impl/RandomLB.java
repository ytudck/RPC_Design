package com.dcqq.rpc.loadbalance.impl;

import com.dcqq.rpc.clilog.CliLog;
import com.dcqq.rpc.loadbalance.LoadBalnce;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

/**
 * @author duchengkun
 * @description todo
 * 随机选取
 * @date 2019-04-23 18:45
 */
public class RandomLB extends CliLog implements LoadBalnce {

    private static AtomicLong factor = new AtomicLong(0l);
    //constructor
    public RandomLB() {
        super(LoggerFactory.getLogger(RandomLB.class));
    }

    //调度轮询  保证雨露均沾
    @Override
    public String compare(List<String> data,String name) {
        long l = factor.addAndGet(1);
        int url_size = data.size();
        return data.get((int)l%url_size);
    }

    @Override
    public void gisnLog(Logger logger, String msg) {
        logger.info(msg);
    }

}
