package com.dcqq.rpc;

import com.dcqq.rpc.clilog.CliLog;
import com.dcqq.rpc.handler.RpcClientHandler;
import com.dcqq.rpc.messagedec.ClientDecode;
import com.dcqq.rpc.messagedec.ClientEncode;
import com.dcqq.rpc.pool.Connection;
import com.dcqq.rpc.pool.NettyConnectionPoolFactory;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioSocketChannel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Closeable;
import java.io.IOException;


/**
 * @author duchengkun
 * @description todo  netty客户端启动
 * @date 2019-04-18 19:19
 */
public class NettyClient extends CliLog implements Closeable {
    private EventLoopGroup work ;
    private String ip;
    private int port;
    private String group_server_name;
    private Bootstrap bootstrap;

    //before constructor
    {
        work = new NioEventLoopGroup(4);
    }

    //constructor
    public NettyClient(String ip, int port,String group_server_name) {
        super(LoggerFactory.getLogger(NettyClient.class));
        this.ip = ip;
        this.port = port;
        this.group_server_name = group_server_name;
        //初始化客户端
        initClient();
    }

    /**
     * 初始化
     */
    private void initClient() {
        try{
            bootstrap = new Bootstrap()
                    .group(work)
                    .channel(NioSocketChannel.class)
                    .handler(new ChannelInitializer<NioSocketChannel>() {
                        @Override
                        protected void initChannel(NioSocketChannel nioSocketChannel) throws Exception {
                                nioSocketChannel.pipeline()
                                        .addLast(new ClientDecode())
                                        .addLast(new ClientEncode())
                                        .addLast(new RpcClientHandler());
                        }
                    }).option(ChannelOption.SO_KEEPALIVE,true);//保持长链接
            //连接服务
            ChannelFuture future = connect_server();
            signLog("the future is "+future.channel().remoteAddress());
            signLog("the future active is "+future.channel().isActive());
            //warpper connection
            Connection connection = new Connection();
            signLog("the connection is "+connection);
            connection.setIsConnected(true);
            connection.setFuture(future);
            connection.setServer_gtorp_name(group_server_name);
            //push into factory
            NettyConnectionPoolFactory.connection_map.put(ip+":"+port,connection);
            NettyConnectionPoolFactory.connection_ip_group.put(ip+":"+port,group_server_name);
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            signLog("------init Netty client-------");
        }
    }

    //连接server
    public ChannelFuture connect_server() throws Exception {
        ChannelFuture future = bootstrap.connect(ip,port);
        if(future.channel() == null){//当连接不存在 or this is fake news
            throw new Exception("the server is not exists,so push an error triger");
        }
        //等待，直到连接成功建立
        future.awaitUninterruptibly();
        return future;
    }

    /**
     * close
     * @throws IOException
     */
    @Override
    public void close() throws IOException {
        try{
            work.shutdownGracefully().sync();
        }catch (Exception e){
            getLogger().error("error->{}",e);
        }
    }

    //log
    @Override
    public void gisnLog(Logger logger, String msg) {
        logger.info(msg);
    }
}
