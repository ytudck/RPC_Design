package com.dcqq.rpc.messagedec;

import com.dcqq.rpc.protocol.HttpParam.RequestBody;
import com.dcqq.rpc.protocol.HttpParam.RequestHeader;
import com.dcqq.rpc.protocol.HttpParam.RpcResquest;
import com.dcqq.rpc.seriable.enums.CompressUtity;
import com.dcqq.rpc.seriable.enums.SeriableUtity;
import com.dcqq.rpc.seriable.interfaces.Compretor;
import com.dcqq.rpc.seriable.interfaces.Serialization;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;

/**
 * @author duchengkun
 * 编码，将请求的封装对象转化为字节数据
 * @description todo
 * @date 2019-04-20 16:08
 */
public class ClientEncode extends MessageToByteEncoder<RpcResquest<RequestBody>> {

    //logger
    private Logger logger = LoggerFactory.getLogger(ClientEncode.class);

    /**
     * 将发送的请求进行编码
     * @param channelHandlerContext
     * @param resquest
     * @param byteBuf
     * @throws Exception
     */
    @Override
    protected void encode(ChannelHandlerContext channelHandlerContext,
                          RpcResquest<RequestBody> resquest, ByteBuf byteBuf) throws Exception {
        RequestHeader requestHeader = resquest.getHeader();
        //写入到消息通道中区
        byteBuf.writeLong(requestHeader.getRequestid());//请求id
        byteBuf.writeByte(requestHeader.getSeritype());//序列化版本
        byteBuf.writeByte(requestHeader.getCompresstype());//压缩版本
        byteBuf.writeByte(requestHeader.getCondition());//这条请求的消息状态

        RequestBody content = resquest.getContent();
        //是否是客户端心跳检测
        if(requestHeader.getCondition() == ClientEventType.HEART_BEAT.getValue()){
            byteBuf.writeInt(0);//消息心跳没有任何请求
            logger.info("client send heart_beat test->{}",new Date());
            return;
        }

        //序列化
        Serialization serialization = SeriableUtity.getSerialization(requestHeader.getSeritype());
        //数据压缩
        Compretor compress = CompressUtity.getCompress(requestHeader.getCompresstype());

        //经过序列化，并且数据压缩之后的格式
        byte[] var1 = compress.compress(serialization.serilize(content));
        logger.info("client warpper data->{}",var1);
        byteBuf.writeInt(var1.length);//请求body的长度
        byteBuf.writeBytes(var1);//发送请求体
        logger.info("client send data successfully");
    }
}
