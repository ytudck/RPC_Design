package com.dcqq.rpc.callback;

/**
 * 接收服务端返回数据的回调
 * @param <T>
 */
public interface Callback<T> {
    void receive(T data);
}
