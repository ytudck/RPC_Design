package com.dcqq.rpc.future;

import com.dcqq.rpc.clilog.CliLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.*;

/**
 * @author duchengkun
 * 线程池工具类
 * @description todo
 * @date 2019-04-24 20:27
 */
public class SyncExcutors extends CliLog {

    private static ThreadPoolExecutor executor = null;
    static {
        executor = new ThreadPoolExecutor(10,
                14,
                40*1000,
                TimeUnit.MILLISECONDS,
                //这个阻塞队列可以提高线程性能
                new LinkedTransferQueue<Runnable>());

        executor.allowCoreThreadTimeOut(true);
    }

    public static ThreadPoolExecutor getExecutor() {
        return executor;
    }

    public SyncExcutors() {
        super(LoggerFactory.getLogger(SyncExcutors.class));
    }

    @Override
    public void gisnLog(Logger logger, String msg) {
        logger.info(msg);
    }

    //执行
    public static void exec(Runnable runnable){
        executor.execute(runnable);
    }
}
