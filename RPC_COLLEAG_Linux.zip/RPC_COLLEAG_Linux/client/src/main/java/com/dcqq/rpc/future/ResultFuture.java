package com.dcqq.rpc.future;

/**
 * 这是一个延时处理的操作
 * @param <T>
 */
public interface ResultFuture<T> {
    //获取数据
    T getData();
}
