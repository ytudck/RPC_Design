package com.dcqq.rpc.proxy;

import com.dcqq.rpc.clilog.CliLog;
import com.dcqq.rpc.config.Byte2IntService;
import com.dcqq.rpc.config.IdService;
import com.dcqq.rpc.future.ResultCatch;
import com.dcqq.rpc.loadbalance.LoadBalnce;
import com.dcqq.rpc.loadbalance.impl.WeightLB;
import com.dcqq.rpc.pool.Connection;
import com.dcqq.rpc.pool.NettyConnectionPool;
import com.dcqq.rpc.pool.NettyConnectionPoolFactory;
import com.dcqq.rpc.protocol.HttpParam.RequestBody;
import com.dcqq.rpc.protocol.HttpParam.RequestHeader;
import com.dcqq.rpc.protocol.HttpParam.RpcResquest;
import com.dcqq.rpc.protocol.util.StringFA;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

/**
 * @author duchengkun
 * @description todo
 * 动态代理
 * @date 2019-04-17 14:17
 */
public class ObjectProxy<T> extends CliLog implements InvocationHandler {

    private Class<T> clazz;
    private String groupname;
    //lock加锁(公平锁,默认是非公平),这个只是会更改状态
    private final ReentrantLock lock = new ReentrantLock(true);
    //连接池
    private static NettyConnectionPool connectionPool =
            new NettyConnectionPool(new NettyConnectionPoolFactory());
    //constructor
    public ObjectProxy(Class<T> clazz,String name) {
        super(LoggerFactory.getLogger(ObjectProxy.class));
        this.clazz = clazz;
        this.groupname = name;
    }

    /**
     * 对接口进行代理，这里是真正的业务操作以及具体的实现
     * @param proxy
     * @param method
     * @param args
     * @return
     * @throws Throwable
     */
    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        lock.lock();

        Object result = null;
        //主程同步(线程同步工具)
        CountDownLatch main_latch = new CountDownLatch(1);
        CountDownLatch latch = new CountDownLatch(1);
        //封装请求
        RpcResquest<RequestBody> resquest = new RpcResquest<RequestBody>();
        //byte 和int 的相互转换
        byte compreetype = Byte2IntService.int1byte(5);
        byte Seritype = Byte2IntService.int1byte(2);
        byte codition = (byte)1;
        //默认request_body的长度为0
        RequestHeader header =
                new RequestHeader(IdService.getId(),Seritype,compreetype,codition,0);
        try{
            String method_name = method.getName();
            //method的参数类型
            Class<?>[] parameterTypes = method.getParameterTypes();
            //获取请求的接口名称
            String declaringinterface = StringFA.lowerFirstCase(method.getDeclaringClass().getSimpleName());
            getLogger().info("client package requestbody:method_name->{},parameterTypes->{},declaringinterface->{},params->{}",
                    method_name,parameterTypes,declaringinterface,args);
            //封装请求
            RequestBody requestBody = new RequestBody(declaringinterface,method_name,args,parameterTypes);
            resquest.setHeader(header);
            resquest.setContent(requestBody);
            //获取该服务调用放的服务组名称
            //发送请求  通过模拟一个负载均衡算法，从连接池中获取数据
            LoadBalnce loadBalnce = new WeightLB();
            //通过计算权重得到
            String compare_url = loadBalnce.compare(NettyConnectionPoolFactory.getKeySets(),groupname);
            signLog("this request get loadbalance is "+compare_url+" the group name is"+groupname);
            //从连接池中获取数据
//            Connection connection= NettyConnectionPoolFactory.connection_map.get(compare_url);
            Connection connection = connectionPool.borrowObject(compare_url);
            signLog("borrow connection from connectionPool is"
                    +connection.getFuture().channel().remoteAddress());
            //异步获取结果(Future + CountDownLatch + Excutors + ReentLock)
            ResultCatch<Object> objectResultCatch = connection.send_request(resquest, 1000l, latch,main_latch);
            //主程 等待异步结果执行完成。
            if(!main_latch.await(5000, TimeUnit.MILLISECONDS)){//等待结果处理超时
                try{//不会影响后续的代码执行
                    throw new Exception("获取处理结果超时!");
                }catch (Exception e){e.printStackTrace();}
            }
            result = objectResultCatch.getData();
            //归还对象(往连接池中归还)
            connectionPool.returnObject(compare_url,connection);
            latch = null;
            main_latch = null;
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            lock.unlock();
        }
        //the finally (invoke)result,the service invoking is backing now
        return result;
    }

    @Override
    public void gisnLog(Logger logger, String msg) {
        logger.info(msg);
    }
}
