package com.dcqq.rpc.zookeeper;

import com.dcqq.rpc.clilog.CliLog;
import com.dcqq.rpc.protocol.ZookeeperConfs.CliZKCnf;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooKeeper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.locks.ReentrantLock;


/**
 * @author duchengkun
 * @description todo
 * Zookeeper的服务发现,学习Springcloud中的服务注册和发现的实现
 * @date 2019-04-20 19:15
 */

public class CliZookeeperDiscover extends CliLog {
    //存放从zookeeper注册中心获取的服务接口
    private static List<String> zook_data_list = new ArrayList<String>();

    private static ReentrantLock lock = new ReentrantLock(true);
    //线程同步信息使用
    private CountDownLatch latch = new CountDownLatch(1);
    private ZooKeeper zooKeeper = null;

    private CliZKCnf zkCnf;
    //constructor
    public CliZookeeperDiscover(ClassLoader loader,String dataName) {
        super(LoggerFactory.getLogger(CliZookeeperDiscover.class));
        setPropers(loader,dataName);
        initdata(this.zkCnf);
    }
    //设置配置文件属性
    private void setPropers(ClassLoader loader,String dataName) {
        try{
            InputStream resourceAsStream = loader.getResourceAsStream("config/zkcnf.properties");
            Properties properties = new Properties();
            properties.load(resourceAsStream);
            this.zkCnf = new CliZKCnf(properties.getProperty("ip"),properties.getProperty("port"),dataName);
        }catch (Exception e){
            getLogger().error("error occur in get client zk cnf->{}",e);
        }
    }

    /**
     * 创建数据结构
     * @param cnf
     */
    private void initdata(CliZKCnf cnf) {
        connectServer(cnf);
        findExposed(zooKeeper);
    }

    /**
     *查找暴露在外部的接口
     */
    public List<String> findExposed(ZooKeeper zooKeeper) {
        List<String> result = new ArrayList<String>();
        try{
            if(zooKeeper != null){
                //new Watcher(){.......}
                List<String> children = zooKeeper.getChildren(CliZooConstant.ZK_REGISTRY_PATH+"/"+this.zkCnf.getDatalocs(), (watchedEvent) -> {
                    if (watchedEvent.getType() == Watcher.Event.EventType.NodeChildrenChanged) {
                        findExposed(zooKeeper);//如果存在子目录，递归调用,分布式文件系统，获取的是其目录名称
                    }
                });

                for(String node : children){
                    byte[] data = zooKeeper.getData(CliZooConstant.ZK_REGISTRY_PATH+"/"+this.zkCnf.getDatalocs() + "/" + node, false, null);
                    result.add(new String(data));
                    signLog("get zk_data from server 120.79.180.60->{"+new String(data)+"}");
                }
                //compare and set
                this.zook_data_list = result;
            }
        }catch (Exception e){
            getLogger().error("client error come up in findExposed->{}",e);
        }
        return result;
    }

    //连接服务
    private void connectServer(CliZKCnf cnf) {
        //zookeeper参数，一切走配置
        String ip = cnf.getIp().trim();
        int port = Integer.valueOf(cnf.getPort().trim());
        lock.lock();
        try{
            zooKeeper = new ZooKeeper(ip+":"+port,CliZooConstant.ZK_SESSION_TIMEOUT,(WatchedEvent watchedEvent)->{
                if(watchedEvent.getState() == Watcher.Event.KeeperState.SyncConnected){
                    latch.countDown();
                }
            });
            //确保服务连接正常,这个要慎用，并非所有情况都适合，一些比较耗时的操作，不建议这样做
            latch.await();
        }catch (Exception e){
            getLogger().error("client connect zookeeper error->{}",e);
        } finally {
            lock.unlock();
        }
    }

    public  List<String> getZook_data_list() {
        return zook_data_list;
    }

    @Override
    public void gisnLog(Logger logger, String msg) {
        logger.info(msg);
    }

    //provide outinterface to outside
    public ZooKeeper getZooKeeper() {
        return zooKeeper;
    }
}
