package com.dcqq.rpc.messagedec;

import com.dcqq.rpc.protocol.HttpParam.ResponseHeader;
import com.dcqq.rpc.protocol.HttpParam.RpcReponse;
import com.dcqq.rpc.seriable.enums.CompressUtity;
import com.dcqq.rpc.seriable.enums.SeriableUtity;
import com.dcqq.rpc.seriable.interfaces.Compretor;
import com.dcqq.rpc.seriable.interfaces.Serialization;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * @author duchengkun
 * 解码
 * @description todo
 * @date 2019-04-20 16:05
 */
public class ClientDecode extends ByteToMessageDecoder{

    //logger
    private Logger logger = LoggerFactory.getLogger(ClientDecode.class);


    /**
     * 从服务端返回的结果，是压缩-序列化之后字节数据
     * @param channelHandlerContext
     * @param byteBuf
     * @param list
     * @throws Exception
     */
    @Override
    protected void decode(ChannelHandlerContext channelHandlerContext,
                          ByteBuf byteBuf, List<Object> list) throws Exception {
        //消息的情况有可能是两种，1.心跳检测。2.正常的请求返回值
        if(byteBuf.readableBytes() < 15){//发现消息丢包的现象，不做处理,此时可以理解为网络错误。
            logger.warn("this meaasge is discard");
            return;
        }
        //byteBuf标记读的位置
        byteBuf.markReaderIndex();
        //请求id
        long requestid = byteBuf.readLong();
        //序列化方式
        byte seritype = byteBuf.readByte();
        //压缩方式
        byte compresstype = byteBuf.readByte();
        //心跳，正常请求
        byte condition = byteBuf.readByte();
        //请求体
        int bodysize = byteBuf.readInt();
        //请求体
        Object response_body = null;

        if(bodysize != 0 && !(condition == ClientEventType.HEART_BEAT.getValue())){
            if(byteBuf.readableBytes() < bodysize){//此时发生了丢包
                byteBuf.resetReaderIndex();//重置读的位置
                return;
            }
            //读取字节
            byte[] result = new byte[bodysize];
            byteBuf.readBytes(result);
            //解压缩,反序列化
            Serialization serialization = SeriableUtity.getSerialization(seritype);
            Compretor compress = CompressUtity.getCompress(compresstype);

            response_body = serialization.descerilize(compress.decompress(result), Object.class);
            logger.info("after uncompress and deseriable the final response_body->{}",response_body);
        }else{
            logger.info("receive heart_beat message from server->{}",
                    channelHandlerContext.channel().remoteAddress());
        }

        //对结果集进行封装操作
        RpcReponse<Object> reponse = new RpcReponse<Object>();
        reponse.setHeader(new ResponseHeader(requestid,seritype,compresstype,condition,bodysize));
        reponse.setContent(response_body);
        //添加到事件链中继续操作,相关逻辑处理在handler中
        list.add(reponse);
    }
}
