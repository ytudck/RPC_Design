package com.dcqq.rpc.loadbalance;

import java.util.List;

/**
 * @author duchengkun
 * @description todo
 * 负载均衡接口
 * @date 2019-04-23 18:44
 */
public interface LoadBalnce {
   public abstract String compare(List<String> data,String name);
}
